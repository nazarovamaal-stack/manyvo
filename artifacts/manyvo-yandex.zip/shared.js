export class RequestError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
    }
}
export function originURL(value) {
    const url = new URL(value);
    if (url.username ||
        url.password ||
        url.search ||
        url.hash ||
        url.pathname !== "/")
        throw new Error("Укажите только адрес сайта, без пути.");
    if (url.protocol !== "https:" &&
        !(url.protocol === "http:" &&
            ["localhost", "127.0.0.1"].includes(url.hostname)))
        throw new Error("Нужен HTTPS. HTTP разрешён только для локального Manyvo.");
    return url.origin;
}
export async function connection() {
    const s = await chrome.storage.local.get("connection");
    return s.connection || null;
}
export async function request(path, method = "GET", body, config) {
    const c = config || (await connection());
    if (!c)
        throw new RequestError("Сначала подключите расширение.", 401);
    const origin = originURL(c.origin);
    if (!path.startsWith("/api/") || path.includes(".."))
        throw new Error("Неверный запрос.");
    const response = await fetch(origin + path, {
        method,
        credentials: "omit",
        signal: AbortSignal.timeout(20000),
        headers: {
            Authorization: "Bearer " + c.token,
            "Content-Type": "application/json",
            "X-Manyvo-Client": "extension",
        },
        body: body === undefined ? undefined : JSON.stringify(body),
    });
    const data = await response.json();
    if (!response.ok)
        throw new RequestError(data.error || "Ошибка Manyvo.", response.status);
    return data;
}
export function safeText(value) {
    return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
export function panelURL(studyId) {
    return (chrome.runtime.getURL("panel.html") +
        (studyId ? "#study/" + encodeURIComponent(studyId) : ""));
}
